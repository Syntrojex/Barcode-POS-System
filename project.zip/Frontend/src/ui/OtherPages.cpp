#include "OtherPages.h"
#include "Dialogs.h"
#include "Theme.h"
#include "Widgets.h"
#include <QCheckBox>
#include <QDoubleSpinBox>
#include <QFile>
#include <QFileDialog>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLineEdit>
#include <QListWidget>
#include <QTableWidget>
#include <QTextStream>
#include <QTime>
#include <QVBoxLayout>

namespace
{
    QTableWidget *makeTable(const QStringList &headers)
    {
        auto *t = new QTableWidget(0, headers.size());
        t->setHorizontalHeaderLabels(headers);
        t->verticalHeader()->hide();
        t->setShowGrid(false);
        t->setEditTriggers(QAbstractItemView::NoEditTriggers);
        t->setSelectionBehavior(QAbstractItemView::SelectRows);
        t->setSelectionMode(QAbstractItemView::SingleSelection);
        t->setFocusPolicy(Qt::NoFocus);
        t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        t->horizontalHeader()->setHighlightSections(false);
        t->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        t->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        return t;
    }
    QTableWidgetItem *item(const QString &s, Qt::Alignment a = Qt::AlignLeft | Qt::AlignVCenter,
                           const QString &color = "", bool bold = false)
    {
        auto *i = new QTableWidgetItem(s);
        i->setTextAlignment(a);
        if (!color.isEmpty())
            i->setForeground(QColor(color));
        if (bold)
        {
            QFont f = i->font();
            f.setBold(true);
            i->setFont(f);
        }
        return i;
    }
    QWidget *wrapW(QWidget *w, Qt::Alignment a = Qt::AlignLeft)
    {
        auto *c = new QWidget;
        auto *h = new QHBoxLayout(c);
        h->setContentsMargins(6, 0, 6, 0);
        h->setAlignment(a | Qt::AlignVCenter);
        h->addWidget(w);
        return c;
    }
    QWidget *pageShell(QWidget *page, QVBoxLayout *&body)
    {
        body = W::pageLayout(page);
        return page;
    }
    [[maybe_unused]] QFrame *kpiCard(const QString &cap, const QString &icon, QLabel *&value)
    {
        auto *c = W::card(nullptr);
        auto *h = new QHBoxLayout(c);
        h->setContentsMargins(14, 10, 14, 10);
        auto *v = new QVBoxLayout;
        v->setSpacing(0);
        v->addWidget(W::label(cap, "caption"));
        value = W::label("", "bigValue");
        value->setStyleSheet("font-size:20px; font-weight:700;");
        v->addWidget(value);
        h->addLayout(v);
        h->addStretch();
        auto *ic = new QLabel;
        ic->setFixedSize(32, 32);
        ic->setAlignment(Qt::AlignCenter);
        ic->setStyleSheet("background:#eef3ff; border-radius:6px;");
        ic->setPixmap(Theme::iconPixmap(icon, Theme::primary, 16));
        h->addWidget(ic);
        return c;
    }
    bool writeCsv(QWidget *parent, const QString &suggested, const QStringList &rows)
    {
        const QString path = QFileDialog::getSaveFileName(parent, "Export CSV", suggested, "CSV (*.csv)");
        if (path.isEmpty())
            return false;
        QFile f(path);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Text))
            return false;
        QTextStream out(&f);
        for (const auto &r : rows)
            out << r << '\n';
        return true;
    }
}

// =================================================================== OrdersPage
OrdersPage::OrdersPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *root;
    pageShell(this, root);

    auto *card = W::card(this);
    auto *v = new QVBoxLayout(card);
    v->setContentsMargins(18, 14, 18, 10);
    v->setSpacing(10);

    auto *tools = new QHBoxLayout;
    tools->setSpacing(8);
    m_orderSearch = new QLineEdit;
    m_orderSearch->setPlaceholderText("Search by order number, customer or phone…");
    m_orderSearch->setMinimumHeight(40);
    m_orderSearch->addAction(Theme::icon("search", Theme::outline, 16), QLineEdit::LeadingPosition);
    m_custSearch = new QLineEdit; // kept hidden: legacy field, not shown
    m_custSearch->hide();
    tools->addWidget(m_orderSearch, 3);
    tools->addStretch(1);
    auto *exp = W::button("Export CSV", "soft", "export");
    tools->addWidget(exp);
    v->addLayout(tools);

    auto *tabs = new QHBoxLayout;
    tabs->setSpacing(6);
    for (const QString &name : {"All", "Paid", "In Progress", "On Hold"})
    {
        auto *b = W::button(name, "tab");
        b->setCheckable(true);
        b->setChecked(name == "All");
        tabs->addWidget(b);
        m_tabs << b;
        connect(b, &QPushButton::clicked, this, [this, name]
                {
            m_filter = name;
            for (auto *t : m_tabs) t->setChecked(t->text() == name);
            rebuild(); });
    }
    tabs->addStretch();
    v->addLayout(tabs);

    m_table = makeTable({"ORDER ID", "DATE & TIME", "CUSTOMER", "ITEMS SUMMARY", "PAYMENT", "AMOUNT", "STATUS", "ACTIONS"});
    W::alignHeaders(m_table, {5}, Qt::AlignRight);
    m_table->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
    for (int c : {0, 1, 4, 5})
        m_table->horizontalHeader()->setSectionResizeMode(c, QHeaderView::ResizeToContents);
    for (int c : {2, 6, 7})
        m_table->horizontalHeader()->setSectionResizeMode(c, QHeaderView::Fixed);
    m_table->setColumnWidth(2, 160);
    m_table->setColumnWidth(6, 104);
    m_table->setColumnWidth(7, 124);
    v->addWidget(m_table, 1);
    m_showing = W::label("", "muted");
    v->addWidget(m_showing);
    root->addWidget(card, 1);

    connect(m_orderSearch, &QLineEdit::textChanged, this, [this]
            { rebuild(); });
    connect(m_custSearch, &QLineEdit::textChanged, this, [this]
            { rebuild(); });
    connect(&AppState::instance(), &AppState::changed, this, &OrdersPage::rebuild);
    connect(exp, &QPushButton::clicked, this, [this]
            {
        QStringList rows{"Order ID,Time,Customer,Contact,Items,Payment,Amount,Status"};
        for (const auto &o : AppState::instance().orders())
            rows << QString("%1,%2,\"%3\",\"%4\",%5,\"%6\",%7,%8").arg(o.id, o.time.toString("yyyy-MM-dd HH:mm:ss"), o.customer, o.contact)
                        .arg(o.itemCount()).arg(o.payment).arg(o.total, 0, 'f', 2).arg(o.status);
        if (writeCsv(this, "orders.csv", rows)) emit toast("Orders exported"); });
    rebuild();
}

void OrdersPage::setSearch(const QString &text)
{
    m_custSearch->clear();
    m_orderSearch->setText(text);
}

void OrdersPage::rebuild()
{
    const auto &all = AppState::instance().orders();
    QString q = m_orderSearch->text().trimmed();
    q.remove('#');
    QVector<OrderRecord> rows;
    int hold = 0;
    for (const auto &o : all)
    {
        if (o.status == "On Hold" || o.status == "In Progress")
            ++hold;
        if (m_filter != "All" && o.status != m_filter)
            continue;
        if (!q.isEmpty() && !o.id.contains(q, Qt::CaseInsensitive) && !o.customer.contains(q, Qt::CaseInsensitive) &&
            !o.contact.contains(q))
            continue;
        rows << o;
    }
    auto &st = AppState::instance();
    (void)hold;
    m_table->setRowCount(rows.size());
    for (int r = 0; r < rows.size(); ++r)
    {
        const auto &o = rows[r];
        m_table->setRowHeight(r, 56);
        m_table->setItem(r, 0, item("#" + o.id, Qt::AlignLeft | Qt::AlignVCenter, "#004ac6", true));
        m_table->setItem(r, 1, item(o.time.toString("yyyy-MM-dd HH:mm") + "\n" + o.shift));
        {
            auto *cw = new QWidget;
            auto *cl = new QVBoxLayout(cw);
            cl->setContentsMargins(8, 4, 8, 4);
            cl->setSpacing(0);
            auto *n = W::label(o.customer + (o.tier == "VIP" ? "  [VIP]" : ""));
            n->setStyleSheet("font-weight:600;");
            auto *c = W::label(o.contact);
            c->setStyleSheet("color:#7b869c; font-size:11.5px;");
            cl->addWidget(n);
            cl->addWidget(c);
            m_table->setCellWidget(r, 2, cw);
        }
        m_table->setItem(r, 3, item(o.summary()));
        m_table->setItem(r, 4, item(o.payment));
        m_table->setItem(r, 5, item(W::money(o.total), Qt::AlignRight | Qt::AlignVCenter, "", true));
        m_table->setCellWidget(r, 6, wrapW(W::badge(o.status, W::statusBadgeKind(o.status))));
        auto *w = new QWidget;
        auto *h = new QHBoxLayout(w);
        h->setContentsMargins(4, 0, 4, 0);
        h->setSpacing(4);
        const OrderRecord copy = o;
        if (o.status == "On Hold")
        {
            auto *res = W::button("Resume", "primary");
            res->setMinimumHeight(26);
            res->setMinimumWidth(72);
            res->setStyleSheet("padding:3px 8px;");
            h->addWidget(res);
            connect(res, &QPushButton::clicked, this, [this, copy]
                    { emit resumeOrder(copy.id); });
        }
        else
        {
            auto *view = W::button("", "flat", "eye");
            view->setToolTip("View details");
            h->addWidget(view);
            connect(view, &QPushButton::clicked, this, [this, copy]
                    { Dialogs::orderDetails(this, copy); });
        }
        auto *rc = W::button("", "flat", "bills");
        rc->setToolTip("Receipt");
        h->addWidget(rc);
        h->addStretch();
        connect(rc, &QPushButton::clicked, this, [this, copy]
                { Dialogs::receipt(this, copy); });
        m_table->setCellWidget(r, 7, w);
    }
    m_showing->setText(QString("%1 of %2 orders").arg(rows.size()).arg(all.size()));
}

// =================================================================== ProductsPage
ProductsPage::ProductsPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *root;
    pageShell(this, root);
    auto *card = W::card(this);
    auto *v = new QVBoxLayout(card);
    v->setContentsMargins(18, 14, 18, 10);
    v->setSpacing(10);
    auto *h = new QHBoxLayout;
    h->addWidget(W::iconLabel("products", Theme::primary, 20));
    h->addWidget(W::label("Product Catalog", "h1"));
    m_count = W::badge("", "blue");
    h->addWidget(m_count);
    h->addStretch();
    m_search = new QLineEdit;
    m_search->setPlaceholderText("Search name, SKU or EAN...");
    m_search->setMinimumWidth(280);
    m_search->addAction(Theme::icon("search", Theme::outline, 16), QLineEdit::LeadingPosition);
    h->addWidget(m_search);
    v->addLayout(h);
    m_table = makeTable({"SKU", "EAN-8", "PRODUCT", "CATEGORY", "LOCATION", "PRICE", "STOCK", "STATUS", ""});
    W::alignHeaders(m_table, {5, 6}, Qt::AlignRight);
    m_table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    for (int c : {0, 1, 3, 4, 5, 6, 7})
        m_table->horizontalHeader()->setSectionResizeMode(c, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(8, QHeaderView::Fixed);
    m_table->setColumnWidth(8, 130);
    v->addWidget(m_table, 1);
    root->addWidget(card, 1);
    connect(m_search, &QLineEdit::textChanged, this, [this]
            { rebuild(); });
    connect(&AppState::instance(), &AppState::changed, this, &ProductsPage::rebuild);
    rebuild();
}

void ProductsPage::setSearch(const QString &text) { m_search->setText(text); }

void ProductsPage::rebuild()
{
    const QString q = m_search->text().trimmed();
    QVector<Product> rows;
    for (const auto &p : AppState::instance().products())
        if (q.isEmpty() || p.name.contains(q, Qt::CaseInsensitive) || p.sku.contains(q, Qt::CaseInsensitive) || p.ean.contains(q))
            rows << p;
    m_count->setText(QString("%1 SKUs").arg(rows.size()));
    m_table->setRowCount(rows.size());
    for (int r = 0; r < rows.size(); ++r)
    {
        const auto &p = rows[r];
        m_table->setRowHeight(r, 44);
        m_table->setItem(r, 0, item(p.sku, Qt::AlignLeft | Qt::AlignVCenter, "#004ac6", true));
        m_table->setItem(r, 1, item(p.ean));
        m_table->setItem(r, 2, item(p.name, Qt::AlignLeft | Qt::AlignVCenter, "", true));
        m_table->setItem(r, 3, item(p.category));
        m_table->setItem(r, 4, item(p.location));
        m_table->setItem(r, 5, item(W::money(p.price), Qt::AlignRight | Qt::AlignVCenter, "", true));
        const bool low = p.stock < p.reorderLimit;
        m_table->setItem(r, 6, item(QString::number(p.stock), Qt::AlignRight | Qt::AlignVCenter, low ? "#ba1a1a" : "", low));
        m_table->setCellWidget(r, 7, wrapW(W::badge(p.stock == 0 ? "Out" : low ? "Low" : "OK", p.stock == 0 ? "red" : low ? "amber" : "green")));
        auto *b = W::button("Add to Order", "mini");
        b->setEnabled(p.stock > 0);
        m_table->setCellWidget(r, 8, wrapW(b));
        const QString ean = p.ean;
        connect(b, &QPushButton::clicked, this, [this, ean]
                { emit addToOrder(ean); });
    }
}

// =================================================================== BillsPage
BillsPage::BillsPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *root;
    pageShell(this, root);
    auto *card = W::card(this);
    auto *v = new QVBoxLayout(card);
    v->setContentsMargins(18, 14, 18, 10);
    v->setSpacing(10);
    auto *h = new QHBoxLayout;
    h->addWidget(W::iconLabel("bills", Theme::primary, 20));
    h->addWidget(W::label("Bills", "h1"));
    h->addStretch();
    m_search = new QLineEdit;
    m_search->setPlaceholderText("Search bill or order ID...");
    m_search->setMinimumWidth(280);
    m_search->addAction(Theme::icon("search", Theme::outline, 16), QLineEdit::LeadingPosition);
    h->addWidget(m_search);
    v->addLayout(h);
    m_table = makeTable({"BILL NO.", "ORDER", "DATE & TIME", "CUSTOMER", "PAYMENT", "TOTAL", "ACTIONS"});
    W::alignHeaders(m_table, {5}, Qt::AlignRight);
    m_table->horizontalHeader()->setSectionResizeMode(6, QHeaderView::Fixed);
    m_table->setColumnWidth(6, 160);
    v->addWidget(m_table, 1);
    root->addWidget(card, 1);
    connect(m_search, &QLineEdit::textChanged, this, [this]
            { rebuild(); });
    connect(&AppState::instance(), &AppState::changed, this, &BillsPage::rebuild);
    rebuild();
}

void BillsPage::rebuild()
{
    const QString q = m_search->text().trimmed();
    QVector<OrderRecord> rows;
    for (const auto &o : AppState::instance().orders())
        if (o.status == "Paid" && (q.isEmpty() || o.id.contains(q, Qt::CaseInsensitive) || o.customer.contains(q, Qt::CaseInsensitive)))
            rows << o;
    m_table->setRowCount(rows.size());
    for (int r = 0; r < rows.size(); ++r)
    {
        const auto &o = rows[r];
        m_table->setRowHeight(r, 46);
        m_table->setItem(r, 0, item("BILL-" + o.id.right(8), Qt::AlignLeft | Qt::AlignVCenter, "#004ac6", true));
        m_table->setItem(r, 1, item(o.id));
        m_table->setItem(r, 2, item(o.time.toString("yyyy-MM-dd HH:mm")));
        m_table->setItem(r, 3, item(o.customer));
        m_table->setItem(r, 4, item(o.payment));
        m_table->setItem(r, 5, item(W::money(o.total), Qt::AlignRight | Qt::AlignVCenter, "", true));
        auto *w = new QWidget;
        auto *h = new QHBoxLayout(w);
        h->setContentsMargins(4, 0, 4, 0);
        auto *view = W::button("View Bill", "mini");
        h->addWidget(view);
        h->addStretch();
        m_table->setCellWidget(r, 6, w);
        const OrderRecord copy = o;
        connect(view, &QPushButton::clicked, this, [this, copy]
                { Dialogs::receipt(this, copy); });
    }
}

// =================================================================== ScannerPage
ScannerPage::ScannerPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *root;
    pageShell(this, root);
    auto *h = new QHBoxLayout;
    h->setSpacing(12);

    auto *cam = W::card(this);
    auto *cv = new QVBoxLayout(cam);
    cv->setContentsMargins(18, 14, 18, 14);
    cv->setSpacing(10);
    W::headerRow(cv, "barcode", "Barcode Scanner");
    m_feed = new CameraFeedWidget;
    m_feed->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    m_feed->setMinimumHeight(300);
    cv->addWidget(m_feed, 1);
    auto *btns = new QHBoxLayout;
    m_toggle = W::button("Stop Cam", "soft", "stop");
    auto *scan = W::button("Scan Now [F9]", "primary", "barcode");
    btns->addWidget(m_toggle);
    btns->addWidget(scan);
    btns->addStretch();
    cv->addLayout(btns);
    auto *mr = new QHBoxLayout;
    m_manual = new QLineEdit;
    m_manual->setPlaceholderText("Or type an 8-digit EAN and press Enter");
    m_manual->setMaxLength(12);
    auto *go = W::button("Lookup", "soft", "search");
    mr->addWidget(m_manual, 1);
    mr->addWidget(go);
    cv->addLayout(mr);
    h->addWidget(cam, 6);

    auto *side = W::card(this);
    auto *sv = new QVBoxLayout(side);
    sv->setContentsMargins(18, 14, 18, 14);
    sv->setSpacing(10);
    W::headerRow(sv, "clock", "Recent Scans");
    m_last = W::label("No scans yet", "h2");
    sv->addWidget(m_last);
    m_history = new QListWidget;
    sv->addWidget(m_history, 1);
    {
        // empty state, shown until the first scan lands in the list
        auto *empty = new QLabel("Scanned products will appear here", m_history);
        empty->setObjectName("muted");
        empty->setAlignment(Qt::AlignCenter);
        auto *el = new QVBoxLayout(m_history);
        el->addWidget(empty);
        auto sync = [this, empty] { empty->setVisible(m_history->count() == 0); };
        connect(m_history->model(), &QAbstractItemModel::rowsInserted, empty, sync);
        connect(m_history->model(), &QAbstractItemModel::rowsRemoved, empty, sync);
    }
    m_send = W::button("Add last scan to order", "primary", "cart");
    m_send->setEnabled(false);
    sv->addWidget(m_send);
    h->addWidget(side, 4);
    root->addLayout(h, 1);

    connect(m_toggle, &QPushButton::clicked, this, [this]
            {
        const bool on = !m_feed->running();
        m_feed->setRunning(on);
        m_toggle->setText(on ? "Stop Cam" : "Start Cam");
        m_toggle->setIcon(Theme::icon(on ? "stop" : "play", Theme::primary, 16)); });
    connect(scan, &QPushButton::clicked, this, &ScannerPage::scanNext);
    auto lookup = [this]
    {
        const auto p = AppState::instance().findByCode(m_manual->text());
        if (!p)
        {
            emit toast("No product found for \"" + m_manual->text() + "\"");
            return;
        }
        m_feed->setCode(p->ean);
        m_lastEan = p->ean;
        m_last->setText(p->name + " • " + W::money(p->price));
        m_history->insertItem(0, QString("%1   %2   %3").arg(QTime::currentTime().toString("HH:mm:ss"), p->ean, p->name));
        m_send->setEnabled(true);
        m_manual->clear();
    };
    connect(go, &QPushButton::clicked, this, lookup);
    connect(m_manual, &QLineEdit::returnPressed, this, lookup);
    connect(m_send, &QPushButton::clicked, this, [this]
            { emit sendToOrder(m_lastEan); });
}

void ScannerPage::scanNext()
{
    if (!m_feed->running())
    {
        emit toast("Camera is stopped - press Start Cam first");
        return;
    }
    const auto &ps = AppState::instance().products();
    const Product &p = ps[m_index++ % ps.size()];
    m_feed->setCode(p.ean);
    m_lastEan = p.ean;
    m_last->setText(p.name + " • " + W::money(p.price));
    m_history->insertItem(0, QString("%1   %2   %3").arg(QTime::currentTime().toString("HH:mm:ss"), p.ean, p.name));
    m_send->setEnabled(true);
}

// =================================================================== SettingsPage
SettingsPage::SettingsPage(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *root;
    pageShell(this, root);
    auto *card = W::card(this);
    card->setMaximumWidth(760);
    auto *v = new QVBoxLayout(card);
    v->setContentsMargins(22, 18, 22, 18);
    v->setSpacing(4);
    W::headerRow(v, "settings", "Terminal Settings");
    auto &s = AppState::instance().settings();

    // One settings row: title + hint on the left, the control on the right.
    auto row = [&](const QString &title, const QString &hint, QWidget *control)
    {
        auto *r = new QHBoxLayout;
        r->setContentsMargins(0, 12, 0, 12);
        r->setSpacing(16);
        auto *t = new QVBoxLayout;
        t->setSpacing(1);
        t->addWidget(W::label(title, "h2"));
        t->addWidget(W::label(hint, "muted"));
        r->addLayout(t, 1);
        r->addWidget(control, 0, Qt::AlignVCenter);
        v->addWidget(W::hline());
        v->addLayout(r);
    };
    auto section = [&](const QString &name)
    {
        v->addSpacing(10);
        v->addWidget(W::label(name, "caption"));
    };

    section("PRICING");
    auto *tax = new QDoubleSpinBox;
    tax->setSuffix(" %");
    tax->setRange(0, 40);
    tax->setValue(s.taxPercent);
    tax->setFixedWidth(130);
    auto *vip = new QDoubleSpinBox;
    vip->setSuffix(" %");
    vip->setRange(0, 50);
    vip->setValue(s.vipDiscountPercent);
    vip->setFixedWidth(130);
    row("GST rate", "Tax rate already included in product prices.", tax);
    row("VIP loyalty discount", "Applied to the order when the VIP toggle is on.", vip);

    section("SCANNING");
    auto *autoAdd = new QCheckBox;
    autoAdd->setChecked(s.autoAddScans);
    auto *beep = new QCheckBox;
    beep->setChecked(s.beepOnScan);
    row("Add scanned items automatically", "Skip the confirmation and add each scan straight to the order.", autoAdd);
    row("Beep on successful scan", "Play a short sound when a barcode is recognised.", beep);

    v->addSpacing(8);
    v->addWidget(W::hline());
    v->addSpacing(10);
    v->addWidget(W::label("Changes apply to new calculations immediately. Settings are kept in memory only.", "muted"));
    auto *h = new QHBoxLayout;
    h->addStretch();
    auto *save = W::button("Apply", "primary", "check");
    h->addWidget(save);
    v->addLayout(h);
    connect(save, &QPushButton::clicked, this, [=, this]
            {
        auto &st = AppState::instance().settings();
        st.taxPercent = tax->value();
        st.vipDiscountPercent = vip->value();
        st.autoAddScans = autoAdd->isChecked();
        st.beepOnScan = beep->isChecked();
        emit toast("Settings applied"); });
    root->addWidget(card);
    root->addStretch();
}
